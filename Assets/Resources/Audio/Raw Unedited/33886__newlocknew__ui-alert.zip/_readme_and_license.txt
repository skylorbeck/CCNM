Sound pack downloaded from Freesound
----------------------------------------

"UI_Alert"

This pack of sounds contains sounds by the following user:
 - newlocknew ( https://freesound.org/people/newlocknew/ )

You can find this pack online at: https://freesound.org/people/newlocknew/packs/33886/


Licenses in this pack (see below for individual sound licenses)
---------------------------------------------------------------

Attribution 4.0: https://creativecommons.org/licenses/by/4.0/
Attribution Noncommercial 4.0: https://creativecommons.org/licenses/by-nc/4.0/


Sounds in this pack
-------------------

  * 647215__newlocknew__uialert-glassy-combine-multi-tone-alert-short-signals-em.mp3
    * url: https://freesound.org/s/647215/
    * license: Attribution Noncommercial 4.0
  * 623119__newlocknew__uialert-interface-alarm-warning-signal-2-em-2lrs.wav
    * url: https://freesound.org/s/623119/
    * license: Attribution Noncommercial 4.0
  * 623118__newlocknew__uialert-interface-alarm-warning-signal-em-2lrs.wav
    * url: https://freesound.org/s/623118/
    * license: Attribution Noncommercial 4.0
  * 563915__newlocknew__tonal-beep-patch-1-select-warning-result-mltprcssng.wav
    * url: https://freesound.org/s/563915/
    * license: Attribution 4.0
  * 563914__newlocknew__tonal-beep-patch-2-select-warning-result-mltprcssng.wav
    * url: https://freesound.org/s/563914/
    * license: Attribution 4.0
  * 563913__newlocknew__tonal-beep-patch-3-select-warning-result-mltprcssng.wav
    * url: https://freesound.org/s/563913/
    * license: Attribution 4.0
  * 563864__newlocknew__ui-6-tonal-beep-aliens-proximity-alert-63osc-chrs-cmpr.wav
    * url: https://freesound.org/s/563864/
    * license: Attribution 4.0
  * 563615__newlocknew__multi-tonal-alarm-4lrs-mltprcssng.wav
    * url: https://freesound.org/s/563615/
    * license: Attribution 4.0


